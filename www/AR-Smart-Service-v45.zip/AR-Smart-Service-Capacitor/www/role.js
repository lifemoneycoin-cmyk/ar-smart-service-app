/* AR Smart Service – version */
window.AR_VERSION='45.0.0';
